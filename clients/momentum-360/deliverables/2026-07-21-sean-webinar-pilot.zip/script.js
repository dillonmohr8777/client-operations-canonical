const event = {
  title: "Build a Business That Grows Without You",
  start: "20260730T180000Z",
  end: "20260730T190000Z",
  location: "Online - meeting link supplied after owner approval",
  description: "A practical local-growth operating system for owners. Prototype date and location must be confirmed before activation."
};

const form = document.querySelector("#registration");
const confirmation = document.querySelector("#confirmation");
const error = document.querySelector("#form-error");
const googleLink = document.querySelector("#google-calendar");

function calendarUrl() {
  const params = new URLSearchParams({
    action: "TEMPLATE",
    text: event.title,
    dates: `${event.start}/${event.end}`,
    details: event.description,
    location: event.location
  });
  return `https://calendar.google.com/calendar/render?${params}`;
}

function icsText() {
  return ["BEGIN:VCALENDAR","VERSION:2.0","PRODID:-//Momentum 360//Webinar Pilot//EN","BEGIN:VEVENT",`UID:sean-webinar-pilot-20260730@momentum360`,`DTSTAMP:${event.start}`,`DTSTART:${event.start}`,`DTEND:${event.end}`,`SUMMARY:${event.title}`,`DESCRIPTION:${event.description}`,`LOCATION:${event.location}`,"END:VEVENT","END:VCALENDAR"].join("\r\n");
}

googleLink.href = calendarUrl();

form.addEventListener("submit", (submitEvent) => {
  submitEvent.preventDefault();
  if (!form.checkValidity()) {
    error.hidden = false;
    form.reportValidity();
    return;
  }
  error.hidden = true;
  form.hidden = true;
  confirmation.hidden = false;
  confirmation.scrollIntoView({ behavior: "smooth", block: "center" });
});

document.querySelector("#download-ics").addEventListener("click", () => {
  const blob = new Blob([icsText()], { type: "text/calendar;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = "build-a-business-webinar.ics";
  anchor.click();
  URL.revokeObjectURL(url);
});
