# Sean webinar pilot prototype

Open `index.html` locally to review the registration experience. The prototype stores nothing and submits nothing. It generates an opt-in Google Calendar link and ICS download only after a visitor completes the form and explicitly consents.

## Included

- Responsive registration page and confirmation state.
- Explicit email reminder and calendar consent controls.
- Google Calendar and ICS actions after registration.
- Funnel event contract in `event-schema.json`.
- Activation and QA checklist in `owner-checklist.md`.

## Activation boundary

Before production, the owners must approve the audience, webinar date, privacy language, form destination, email sender, meeting link, analytics destination, and strategy-call route. Nothing in this package sends a message, stores contact data, or changes a live account.
