---
name: Momentum Digital and AI division v2 draft
description: The working publication; extracted from this implemented review board
colors:
  paper: "#fbfaf7"
  surface: "#eceae4"
  ink: "#14181b"
  muted: "#565f64"
  blue: "#1e73be"
  orange: "#f58320"
  deep: "#0e1a22"
  on-deep: "#f2f6f8"
  orange-ink: "#96490b"
typography:
  display:
    fontFamily: "Archivo Black, sans-serif"
    fontSize: "clamp(2.6rem, 6.3vw, 6rem)"
    fontWeight: 400
    lineHeight: 1.02
    letterSpacing: "-0.03em"
  body:
    fontFamily: "Nunito Sans, sans-serif"
    fontSize: "1.125rem"
    lineHeight: 1.6
  label:
    fontFamily: "Nunito Sans, sans-serif"
    fontSize: "0.875rem"
rounded:
  control: "12px"
spacing:
  xs: "8px"
  sm: "16px"
  md: "24px"
  lg: "40px"
  xl: "80px"
components:
  button-primary:
    backgroundColor: "{colors.orange}"
    textColor: "{colors.ink}"
    rounded: "{rounded.control}"
    padding: "13px 21px"
  service:
    backgroundColor: "{colors.blue}"
    textColor: "#ffffff"
    rounded: "{rounded.control}"
    padding: "40px"
---
# Momentum design system v2

## Overview
**The working publication.** This is a scan-mode record of the implemented local board, not approved Momentum policy. Recognizable identity gets a more deliberate editorial language: strong typography, practical diagrams, quiet reading surfaces and meaningful motion. The v1 tokens and source logos remain untouched.

## Colors
Blue and orange are retained from existing source tokens. Paper, surface, ink, muted and deep also reuse that source vocabulary. Use white on blue; ink on orange. Orange-ink is the dark text variant. Never white body text on orange. Deep supports high-contrast cover and video typography. Avoid introducing new gradients or arbitrary accent colors per asset.

## Typography
Archivo Black is the retained display face, self-hosted, weight 400. Nunito Sans is the self-hosted reading/control face. Display is capped at 96px, tracking -0.03em. Body is 18px with 1.6 line height and maximum 68ch measure. Caveat and IBM Plex Mono exist in prior work; this focused draft does not use them or remove them from canonical policy. Chapter numerals convey actual reading sequence. Do not use decorative section counters or uppercase labels above headlines.

## Layout
1440px maximum content width, desktop 48px side gutters, mobile 20px. The paired editorial spread and other two-column layouts stack below 850px. A 40px desktop page inset becomes 26px on mobile. Use broad editorial fields and rules rather than repetitive same-size cards. Maintain a visible hierarchy between display, section heading, body and captions.

## Elevation & Depth
Mostly flat color fields and fine structural rules. The ebook paper uses one soft ambient shadow (0 18px 48px, deep at 12%); no glow or glass. Do not add a shadow under already-bordered cards.

## Shapes
12px control and service-card radius. Icons share a 32px viewBox, 1.6px round stroke, no fill. Circular nodes are process geometry, not decorative picture substitutes. Preserve every logo aspect ratio and byte-exact source.

## Components
Use the orange/ink button for a clear action; the outlined variant for secondary actions. Both have hover, active context and keyboard focus treatment. Navigation uses real section links. Chapter buttons update reading content with aria-pressed and polite announcement. Native inputs include required validation and confirmation feedback; the demo transmits nothing. Ten standalone SVG assets plus a reusable sprite cover discover, route, automate, qualify, connect, measure, publish, compose, guard and handoff.

The one sustained motion is a workflow trace. Pause control stops animation globally. Icons respond once to hover/focus; title reveal is user-triggered. CSS prefers-reduced-motion disables every animation and smooth scrolling. No logo movement. Print mode is static and preserves color/reading hierarchy.

Logo usage: full lockup on a calm light field, at least half a mark-height clear space; compact mark only where context establishes identity. No new white/recolored variants are manufactured. The draft's Digital assets must never stand in for a Momentum 360 logo.

## Do's and Don'ts
Do preserve exact brand assets and readable text contrast. Do tie motion to a real sequence or deliberate interaction. Do keep long reading on paper. Do preserve brand separation. Do label sample copy as illustrative.

Do not treat this draft as approved policy. Do not distort or animate logos, use emoji icons, substitute a 360 identity, add unsupported outcome claims, or promise animation inside a static PDF.
