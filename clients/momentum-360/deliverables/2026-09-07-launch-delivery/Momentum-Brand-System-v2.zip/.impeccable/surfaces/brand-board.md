# Brand board
Mode: Experience with Read specimens.
Status: code-led proposed direction; root performs independent review.
Direction: The working publication. Typography carries impact; detailed workflow geometry explains the product; warm paper supports long reading. Blue identifies and orange directs. No decorative logo animation or generic icon-card page scaffolding.
First viewport: exact logo on paper, a large declarative headline, concise draft context, followed by a split deep/orange editorial cover and semantic routing diagram.
Signature interaction: switching chapters changes both pages and page number while preserving readable layout. Diagram traces one routing flow with pause and reduced-motion controls. Icons move once on interaction; replayable end-card title resolves fully.
Responsive: paired editorial pages stack below 850px; navigation wraps; icons use two columns; all content remains available.
Assumptions: explicit brief used in place of a separate direction interview to keep parallel work bounded. No approved comp exists; no generation was requested for this worker.
